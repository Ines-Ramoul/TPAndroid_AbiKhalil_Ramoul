package adapters

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainer
import fr.unice.miage.mbds.exemples.R

class FragmentContainer  {



}