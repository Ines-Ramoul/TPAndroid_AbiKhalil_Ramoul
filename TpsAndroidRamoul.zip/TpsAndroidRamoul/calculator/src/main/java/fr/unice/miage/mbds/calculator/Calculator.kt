package fr.unice.miage.mbds.calculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import fr.unice.miage.mbds.calculator.R
import kotlinx.android.synthetic.main.activity_calculator.*
import net.objecthunter.exp4j.ExpressionBuilder


class Calculator : AppCompatActivity() {

    lateinit var txtInput: TextView
    lateinit var txtOutput: TextView
    var error : Boolean = true
  //  var length : Int = txtInput.text.toString().length


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)
        txtInput = findViewById(R.id.txtInput)
        txtOutput = findViewById(R.id.txtOutput)
    }

    var lastNum : Boolean = false

    fun appendNumber(view: View) {
        txtInput.append((view as Button).text)
        lastNum=true
    }

    var lastDot : Boolean = false

    fun appendDot(view: View) {
        if (!lastDot and  lastNum and !error) {
            txtInput.append((view as Button).text)

            lastDot = true;
        }
    }

    var bracketOp : Boolean = false
    fun appendBracket(view: View){
        txtInput.append((view as Button).text)
       /* if (bracketOp){
            buttonClosingBracket.isClickable = false
            txtInput.append((view as Button).text)
        } else {
            txtInput.append((view as Button).text)
            bracketOp=true
        }*/
    }



    fun onBack(view: View){
        if(!txtInput.text.isEmpty()){
         //   txtInput.text.toString().substring(0,txtInput.text.length-1)
            txtInput.text.dropLast(1)
        }
    }



    fun onClear(view: View){
        txtInput.text=""
        txtOutput.text=""
        //this.txtInput.text = ""
        lastNum = false
        lastDot = false
        error = false
    }

    fun appendOperator(view: View){
        txtInput.append((view as Button).text)
        //on reset les flags lastDot et lastNum pour passer sur l'autre terme de l'operation
        lastDot=false
        lastNum=false
    }

    fun onEgal(view: View){
        if(lastNum and !error){
            val txt=txtInput.text.toString()
            val expression= ExpressionBuilder(txt).build()
            try {
                // Calculate the result and display
                val result = expression.evaluate()
                txtOutput.text = result.toString()
                Toast.makeText(baseContext,
                    "$txt = $result",
                    Toast.LENGTH_LONG
                ).show()
                //lastDot = true // Result contains a dot
            } catch (ex: ArithmeticException) {
                // Display an error message
                txtOutput.text = "Error"
                lastNum = false
                lastDot=false
                error=true
            }
        }
    }
}
